/* Walkie v21: real, privacy-safe website request feed for active executors. */
(() => {
  const byId = (id) => document.getElementById(id);
  const escapeHtml = (value) => String(value ?? '').replace(/[&<>"']/g, (ch) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  const serviceNames = {walk:'Выгул', boarding:'Передержка', sitter:'Зооняня', training:'Кинолог', grooming:'Груминг', transfer:'Сопровождение'};
  const originalTab = window.setExecutorTab;
  let selectedTab = 'available';

  function setActiveTab(tab) {
    ['available', 'mine', 'site'].forEach((name) => byId('exec' + name[0].toUpperCase() + name.slice(1))?.classList.toggle('active', name === tab));
    const note = byId('siteRequestNote');
    if (note) note.hidden = tab !== 'site';
  }

  window.setExecutorTab = function(tab) {
    selectedTab = tab;
    if (tab === 'site') {
      setActiveTab('site');
      return window.loadSiteRequestsV21();
    }
    setActiveTab(tab);
    return typeof originalTab === 'function' ? originalTab(tab) : window.loadExecutor?.();
  };

  window.loadSiteRequestsV21 = async function() {
    const list = byId('executorList');
    if (!list) return;
    list.innerHTML = '<div class="notice">Загружаем заявки с сайта…</div>';
    try {
      const result = await window.api('/api/site-requests');
      const requests = Array.isArray(result?.requests) ? result.requests : [];
      if (!requests.length) {
        list.innerHTML = '<div class="notice">Подходящих активных заявок сейчас нет. Новые появятся здесь автоматически.</div>';
        return;
      }
      list.innerHTML = requests.map((r) => {
        const retry = r.already_interested && !r.interest_synced;
        const label = r.interest_synced ? 'Отклик передан менеджеру' : retry ? 'Повторить передачу' : 'Откликнуться менеджеру';
        const button = `<button class="btn ${retry ? 'btn-gold' : r.interest_synced ? 'btn-dark' : 'btn-gold'} btn-wide" ${r.interest_synced ? 'disabled' : ''} onclick="interestSiteRequestV21(${Number(r.id)},this)">${label}</button>`;
        const syncNote = retry ? '<p class="v21-site-sync-note" role="status">Отклик сохранён. Сайт пока не подтвердил получение — повторите отправку.</p>' : '';
        return `<article class="v21-site-request"><div class="v21-site-request__top"><div><span class="v21-site-kicker">ЗАЯВКА С САЙТА · #${Number(r.id)}</span><h3>${escapeHtml(serviceNames[r.service] || r.service || 'Услуга')}</h3></div><span class="v21-site-sla">${Number(r.sla_minutes) > 0 ? `${Number(r.sla_minutes)} мин в подборе` : 'Новая'}</span></div><div class="v21-site-meta"><span><i class="fa-regular fa-calendar"></i>${escapeHtml(r.date)} · ${escapeHtml(r.time)}</span><span><i class="fa-solid fa-location-dot"></i>${escapeHtml([r.city,r.district].filter(Boolean).join(' · ') || 'Район уточняется')}</span><span><i class="fa-regular fa-clock"></i>${Number(r.duration_min) || 60} минут</span></div><p>Данные владельца и адрес скрыты до назначения через менеджера.</p>${syncNote}${button}</article>`;
      }).join('');
    } catch (error) {
      list.innerHTML = `<div class="notice">${escapeHtml(error?.message || 'Не удалось загрузить заявки. Проверьте подключение и попробуйте ещё раз.')}</div><button class="btn btn-dark btn-wide" onclick="loadSiteRequestsV21()">Повторить</button>`;
    }
  };

  window.interestSiteRequestV21 = async function(id, button) {
    if (!Number.isInteger(Number(id)) || Number(id) <= 0 || !button) return;
    button.disabled = true;
    button.textContent = 'Отправляем отклик…';
    try {
      const response = await window.api(`/api/site-requests/${Number(id)}/interest`, {method:'POST', body:JSON.stringify({})});
      button.textContent = response?.site_synced ? 'Отклик передан менеджеру' : 'CRM сайта не ответила — повторить';
      if (typeof window.showToast === 'function') window.showToast(response?.site_synced ? 'Менеджер увидит ваш отклик в Walkie' : 'Отклик сохранён. Повторите передачу в CRM сайта.');
      await window.loadSiteRequestsV21();
    } catch (error) {
      button.disabled = false;
      button.textContent = 'Откликнуться менеджеру';
      if (typeof window.showToast === 'function') window.showToast(error?.message || 'Не удалось отправить отклик');
      else alert(error?.message || 'Не удалось отправить отклик');
    }
  };

  function moscowTomorrow() {
    const parts = new Intl.DateTimeFormat('en-CA', {timeZone:'Europe/Moscow',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date());
    const values = Object.fromEntries(parts.map((p) => [p.type,p.value]));
    const date = new Date(Date.UTC(Number(values.year),Number(values.month)-1,Number(values.day)+1));
    return date.toISOString().slice(0,10);
  }
  function setBookingMin() {
    const input = byId('bookDate');
    if (!input) return;
    const min = moscowTomorrow();
    input.min = min;
    if (input.value && input.value < min) input.value = min;
  }
  document.addEventListener('DOMContentLoaded', setBookingMin);
  document.addEventListener('click', (event) => {
    if (event.target.closest('[onclick*="showView(\'booking\'"]')) setTimeout(setBookingMin, 0);
  });
  setBookingMin();
})();
