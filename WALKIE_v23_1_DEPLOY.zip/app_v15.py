import json
import hashlib
import hmac
import os
import threading
import time
import urllib.parse
import urllib.request
import urllib.error
from datetime import datetime, timedelta, timezone
from pathlib import Path

import app_v14 as v14

base = v14.base
SLOT_START_MIN = 8 * 60
SLOT_END_MIN = 22 * 60
SLOT_STEP_MIN = 30
WALKIE_SITE_WEBHOOK_SECRET = os.getenv("WALKIE_SITE_WEBHOOK_SECRET", "").strip()
WALKIE_SITE_CALLBACK_URL = os.getenv("WALKIE_SITE_CALLBACK_URL", "").strip()
MANAGER_TELEGRAM_IDS = [x.strip() for x in os.getenv("MANAGER_TELEGRAM_IDS", "").replace(";", ",").split(",") if x.strip().isdigit()]
SITE_SERVICE_IDS = {"walk": 1, "boarding": 2, "sitter": 3, "training": 4, "grooming": 6, "transfer": 8}


def push_site_interest(site_id, executor_id, executor_name, city, area, service):
    """Send an executor interest event back to the WP CRM without customer data."""
    if not WALKIE_SITE_CALLBACK_URL.startswith("https://") or not WALKIE_SITE_WEBHOOK_SECRET:
        return False
    payload = {"event":"walkie.executor.interested", "site_request_id":int(site_id),
        "executor_id":int(executor_id), "executor_name":str(executor_name or "")[:100],
        "city":str(city or "")[:80], "area":str(area or "")[:120],
        "service":str(service or "")[:30], "created_at":v14.now_iso()}
    raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    signature = "sha256=" + hmac.new(WALKIE_SITE_WEBHOOK_SECRET.encode("utf-8"), raw, hashlib.sha256).hexdigest()
    req = urllib.request.Request(WALKIE_SITE_CALLBACK_URL, data=raw,
        headers={"Content-Type":"application/json", "X-Walkie-Signature":signature}, method="POST")
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *_args, **_kwargs):
            return None
    opener = urllib.request.build_opener(NoRedirect)
    try:
        with opener.open(req, timeout=4) as response:
            result = json.loads(response.read(8192).decode("utf-8"))
            return response.status == 200 and bool(result.get("ok"))
    except Exception:
        return False


def init_v15():
    v14.init_v14()
    c = base.conn()
    c.executescript("""
      CREATE INDEX IF NOT EXISTS idx_orders_executor_time
      ON orders(executor_id, target_executor_id, scheduled_date, scheduled_time, status);
      CREATE INDEX IF NOT EXISTS idx_availability_executor_time
      ON availability(executor_id, start_at, end_at);
      CREATE TABLE IF NOT EXISTS executor_applications(
        user_id INTEGER PRIMARY KEY,
        data_json TEXT NOT NULL DEFAULT '{}',
        status TEXT NOT NULL DEFAULT 'submitted',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );
      CREATE TABLE IF NOT EXISTS site_requests(
        site_request_id INTEGER PRIMARY KEY,
        service TEXT NOT NULL DEFAULT '', city TEXT NOT NULL DEFAULT '', district TEXT NOT NULL DEFAULT '',
        scheduled_date TEXT NOT NULL DEFAULT '', scheduled_time TEXT NOT NULL DEFAULT '',
        duration_min INTEGER NOT NULL DEFAULT 60, status TEXT NOT NULL DEFAULT 'new',
        sla_minutes INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL DEFAULT '', updated_at TEXT NOT NULL DEFAULT '',
        last_event_at TEXT NOT NULL DEFAULT '', last_event_hash TEXT NOT NULL DEFAULT '',
        assigned_executor_id INTEGER NOT NULL DEFAULT 0,
        unassigned_notified_minutes INTEGER NOT NULL DEFAULT 0
      );
      CREATE TABLE IF NOT EXISTS site_request_interests(
        id INTEGER PRIMARY KEY AUTOINCREMENT, site_request_id INTEGER NOT NULL, executor_id INTEGER NOT NULL,
        created_at TEXT NOT NULL, sync_status TEXT NOT NULL DEFAULT 'pending',
        sync_attempts INTEGER NOT NULL DEFAULT 0, last_sync_at TEXT NOT NULL DEFAULT '',
        sync_error TEXT NOT NULL DEFAULT '', UNIQUE(site_request_id, executor_id)
      );
    """)
    v14.ensure_column(c, "site_requests", "last_event_hash", "TEXT NOT NULL DEFAULT ''")
    v14.ensure_column(c, "site_requests", "assigned_executor_id", "INTEGER NOT NULL DEFAULT 0")
    v14.ensure_column(c, "site_requests", "unassigned_notified_minutes", "INTEGER NOT NULL DEFAULT 0")
    v14.ensure_column(c, "site_request_interests", "sync_status", "TEXT NOT NULL DEFAULT 'pending'")
    v14.ensure_column(c, "site_request_interests", "sync_attempts", "INTEGER NOT NULL DEFAULT 0")
    v14.ensure_column(c, "site_request_interests", "last_sync_at", "TEXT NOT NULL DEFAULT ''")
    v14.ensure_column(c, "site_request_interests", "sync_error", "TEXT NOT NULL DEFAULT ''")
    c.commit(); c.close()


def process_site_webhook(raw_body, signature, secret=None):
    secret = WALKIE_SITE_WEBHOOK_SECRET if secret is None else str(secret)
    if not secret:
        return {"ok": False, "status": 503, "error": "Синхронизация сайта не настроена"}
    expected = "sha256=" + hmac.new(secret.encode("utf-8"), raw_body, hashlib.sha256).hexdigest()
    if not signature or not hmac.compare_digest(expected, str(signature)):
        return {"ok": False, "status": 401, "error": "Подпись не прошла проверку"}
    try:
        payload = json.loads(raw_body.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return {"ok": False, "status": 400, "error": "Некорректный JSON"}
    if not isinstance(payload, dict):
        return {"ok": False, "status": 400, "error": "Некорректное событие"}
    event = str(payload.get("event") or "")
    data = payload.get("data") if isinstance(payload.get("data"), dict) else {}
    try:
        site_id = int(payload.get("id") or 0)
    except (TypeError, ValueError):
        site_id = 0
    if site_id <= 0 or event not in {"walkie.request.created", "walkie.request.status_changed", "walkie.request.rescheduled", "walkie.request.unassigned", "walkie.request.executor_assigned"}:
        return {"ok": False, "status": 400, "error": "Событие не поддерживается"}
    stamp = str(payload.get("occurred_at") or v14.now_iso())[:40]
    try:
        datetime.fromisoformat(stamp.replace("Z", "+00:00"))
    except ValueError:
        return {"ok": False, "status": 400, "error": "Некорректное время события"}
    c = base.conn()
    event_hash = hashlib.sha256(raw_body).hexdigest()
    prior = c.execute("SELECT last_event_at,last_event_hash FROM site_requests WHERE site_request_id=?", (site_id,)).fetchone()
    if prior and prior["last_event_hash"] == event_hash:
        c.close()
        return {"ok": True, "id": site_id, "duplicate": True, "notify_unassigned": False}
    if prior and prior["last_event_at"]:
        try:
            old_dt = datetime.fromisoformat(prior["last_event_at"].replace("Z", "+00:00"))
            new_dt = datetime.fromisoformat(stamp.replace("Z", "+00:00"))
            if new_dt < old_dt:
                c.close()
                return {"ok": True, "id": site_id, "stale": True, "notify_unassigned": False}
        except ValueError:
            pass
    current = c.execute("SELECT * FROM site_requests WHERE site_request_id=?", (site_id,)).fetchone()
    row = dict(current) if current else {}
    status = "assigned" if event == "walkie.request.executor_assigned" else str(data.get("status") or row.get("status") or "new")[:24]
    if status not in {"new", "contacted", "matching", "assigned", "confirmed", "in_progress", "completed", "cancelled"}:
        c.close()
        return {"ok": False, "status": 400, "error": "Статус заявки не поддерживается"}
    try:
        duration_min = int(data.get("duration") or row.get("duration_min") or 60)
        sla_minutes = int(data.get("minutes") or row.get("sla_minutes") or 0)
        assigned_executor_id = max(0, int(data.get("executor_id") or 0)) if event == "walkie.request.executor_assigned" else max(0, int(data.get("assigned_executor_id", row.get("assigned_executor_id", 0)) or 0))
        unassigned_notified_minutes = max(0, int(row.get("unassigned_notified_minutes", 0) or 0))
    except (TypeError, ValueError):
        c.close()
        return {"ok": False, "status": 400, "error": "Некорректная длительность заявки"}
    notify_unassigned = event == "walkie.request.unassigned" and sla_minutes > unassigned_notified_minutes
    if event == "walkie.request.unassigned":
        unassigned_notified_minutes = max(unassigned_notified_minutes, sla_minutes)
    elif status == "matching":
        # Reopening matching starts a new search cycle and a new SLA notification window.
        unassigned_notified_minutes = 0
    update = {
        "service": str(data.get("service") or row.get("service") or "")[:30],
        "city": str(data.get("city") or row.get("city") or "")[:40],
        "district": str(data.get("district") or row.get("district") or "")[:120],
        "scheduled_date": str(data.get("date") or row.get("scheduled_date") or "")[:10],
        "scheduled_time": str(data.get("time") or row.get("scheduled_time") or "")[:5],
        "duration_min": max(15, min(2880, duration_min)),
        "status": status,
        "sla_minutes": max(0, min(1440, sla_minutes)),
        "created_at": str(row.get("created_at") or stamp)[:40],
        "updated_at": stamp,
        "last_event_at": stamp,
        "last_event_hash": event_hash,
        "assigned_executor_id": assigned_executor_id if status == "assigned" else 0,
        "unassigned_notified_minutes": unassigned_notified_minutes,
    }
    c.execute("""INSERT INTO site_requests(site_request_id,service,city,district,scheduled_date,scheduled_time,duration_min,status,sla_minutes,created_at,updated_at,last_event_at,last_event_hash,assigned_executor_id,unassigned_notified_minutes)
        VALUES(:site_id,:service,:city,:district,:scheduled_date,:scheduled_time,:duration_min,:status,:sla_minutes,:created_at,:updated_at,:last_event_at,:last_event_hash,:assigned_executor_id,:unassigned_notified_minutes)
      ON CONFLICT(site_request_id) DO UPDATE SET service=excluded.service,city=excluded.city,district=excluded.district,
        scheduled_date=excluded.scheduled_date,scheduled_time=excluded.scheduled_time,duration_min=excluded.duration_min,
        status=excluded.status,sla_minutes=excluded.sla_minutes,updated_at=excluded.updated_at,last_event_at=excluded.last_event_at,last_event_hash=excluded.last_event_hash,assigned_executor_id=excluded.assigned_executor_id,unassigned_notified_minutes=excluded.unassigned_notified_minutes""",
        {"site_id": site_id, **update})
    c.commit()
    c.close()
    return {"ok": True, "id": site_id, "notify_unassigned": notify_unassigned, "minutes": update["sla_minutes"]}


def process_site_ping(raw_body, signature, secret=None):
    """Authenticate a diagnostics ping without creating or changing a request."""
    secret = WALKIE_SITE_WEBHOOK_SECRET if secret is None else str(secret)
    if not secret:
        return {"ok": False, "status": 503, "error": "Синхронизация сайта не настроена"}
    expected = "sha256=" + hmac.new(secret.encode("utf-8"), raw_body, hashlib.sha256).hexdigest()
    if not signature or not hmac.compare_digest(expected, str(signature)):
        return {"ok": False, "status": 401, "error": "Подпись не прошла проверку"}
    try:
        payload = json.loads(raw_body.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return {"ok": False, "status": 400, "error": "Некорректный JSON"}
    if not isinstance(payload, dict) or payload.get("event") != "walkie.integration.ping":
        return {"ok": False, "status": 400, "error": "Некорректная проверка связи"}
    nonce = str(payload.get("nonce") or "")
    if not nonce or len(nonce) > 100:
        return {"ok": False, "status": 400, "error": "Некорректный nonce"}
    try:
        stamp = datetime.fromisoformat(str(payload.get("occurred_at") or "").replace("Z", "+00:00"))
        if stamp.tzinfo is None:
            stamp = stamp.replace(tzinfo=timezone.utc)
        age = abs((datetime.now(timezone.utc) - stamp.astimezone(timezone.utc)).total_seconds())
    except ValueError:
        return {"ok": False, "status": 400, "error": "Некорректное время проверки"}
    if age > 300:
        return {"ok": False, "status": 400, "error": "Проверка устарела"}
    return {"ok": True, "event": "walkie.integration.ping", "nonce": nonce}


def deliver_site_interest(site_id, executor_id, profile, service):
    """Retry CRM delivery until acknowledged; keep the first local interest idempotent."""
    c = base.conn()
    row = c.execute("SELECT sync_status,sync_attempts FROM site_request_interests WHERE site_request_id=? AND executor_id=?",
                    (int(site_id), int(executor_id))).fetchone()
    if not row:
        c.close()
        return {"site_synced": False, "sync_status": "missing", "sync_attempts": 0}
    if row["sync_status"] == "sent":
        result = {"site_synced": True, "sync_status": "sent", "sync_attempts": int(row["sync_attempts"] or 0)}
        c.close()
        return result
    synced = push_site_interest(site_id, executor_id, profile["display_name"], profile["city"], profile["area"], service)
    attempts = int(row["sync_attempts"] or 0) + 1
    error = "" if synced else "Сайт не подтвердил получение; нажмите повторить передачу."
    c.execute("UPDATE site_request_interests SET sync_status=?,sync_attempts=?,last_sync_at=?,sync_error=? WHERE site_request_id=? AND executor_id=?",
              ("sent" if synced else "failed", attempts, v14.now_iso(), error, int(site_id), int(executor_id)))
    c.commit()
    c.close()
    return {"site_synced": bool(synced), "sync_status": "sent" if synced else "failed", "sync_attempts": attempts}


_orig_serialize_order = v14.serialize_order


def serialize_order_v15(c, row, viewer_id, viewer_role):
    d = _orig_serialize_order(c, row, viewer_id, viewer_role)
    photo = ""
    if d.get("pet_id"):
        pet = c.execute("SELECT photo_path FROM pets WHERE id=?", (d["pet_id"],)).fetchone()
        if pet:
            photo = pet["photo_path"] or ""
    d["pet_photo_url"] = photo
    return d


v14.serialize_order = serialize_order_v15


def minute_to_time(value):
    return f"{value // 60:02d}:{value % 60:02d}"


def parse_order_id(path, suffix=None):
    parts = path.strip("/").split("/")
    if len(parts) < 3 or parts[:2] != ["api", "orders"]:
        return None
    if suffix and (len(parts) < 4 or parts[-1] != suffix):
        return None
    try:
        return int(parts[2])
    except Exception:
        return None


def executor_slot_reason(c, executor_id, date_str, time_str, duration, exclude_order_id=None):
    start = v14.parse_dt(date_str, time_str)
    if not start:
        return "Некорректное время"
    end = start + timedelta(minutes=max(1, int(duration or 60)))
    rows = c.execute(
        """SELECT * FROM orders
        WHERE status IN ('open','accepted','in_progress')
          AND (executor_id=? OR target_executor_id=?)""",
        (executor_id, executor_id),
    ).fetchall()
    for row in rows:
        if exclude_order_id and int(row["id"]) == int(exclude_order_id):
            continue
        a, b = v14.order_range(row)
        if a and v14.ranges_overlap(start, end, a, b):
            return "У исполнителя уже есть заказ"
    for block in c.execute(
        "SELECT * FROM availability WHERE executor_id=?", (executor_id,)
    ).fetchall():
        try:
            a = datetime.fromisoformat(block["start_at"])
            b = datetime.fromisoformat(block["end_at"])
        except Exception:
            continue
        if v14.ranges_overlap(start, end, a, b):
            return block["note"] or "Исполнитель недоступен"
    return ""


def order_edit_payload(c, uid, order, data):
    date_str = (data.get("scheduled_date") or order["scheduled_date"] or "").strip()
    time_str = (data.get("scheduled_time") or order["scheduled_time"] or "").strip()
    start = v14.parse_dt(date_str, time_str)
    if not start:
        raise ValueError("Укажите дату и время")
    if start < datetime.now() - timedelta(minutes=1):
        raise ValueError("Выбранное время уже прошло")
    try:
        duration = int(data.get("duration_min") or order["duration_min"] or 60)
    except Exception:
        duration = int(order["duration_min"] or 60)
    duration = max(30, min(43200, duration))
    try:
        pet_id = int(data.get("pet_id", order["pet_id"]))
    except Exception:
        raise ValueError("Выберите питомца")
    item_id = int(order["item_id"])
    if item_id == 2 and (duration % 1440 or not 1440 <= duration <= 43200):
        raise ValueError("Передержка оформляется целыми сутками от 1 до 30.")
    if item_id == 2:
        try:
            stored_ids = [int(x) for x in json.loads(order["pet_ids_json"] or "[]")]
        except (TypeError, ValueError, json.JSONDecodeError):
            stored_ids = []
        if not stored_ids:
            stored_ids = [pet_id]
        raw_ids = data.get("pet_ids")
        try:
            pet_ids = list(dict.fromkeys(int(x) for x in raw_ids)) if isinstance(raw_ids, list) else (stored_ids if pet_id == stored_ids[0] else [pet_id])
        except (TypeError, ValueError):
            raise ValueError("Выберите корректный состав питомцев")
        if pet_ids:
            pet_id = pet_ids[0]
    else:
        pet_ids = [pet_id]
    if not pet_ids or len(pet_ids) > 8:
        raise ValueError("Выберите питомца")
    placeholders = ",".join("?" for _ in pet_ids)
    pets = c.execute(f"SELECT * FROM pets WHERE user_id=? AND id IN ({placeholders})", (uid, *pet_ids)).fetchall()
    pets_by_id = {int(row["id"]): row for row in pets}
    if len(pets_by_id) != len(pet_ids):
        raise ValueError("Питомец не найден")
    pets = [pets_by_id[pid] for pid in pet_ids]
    pet = pets[0]
    address = (
        (data.get("address") if "address" in data else order["address"]) or ""
    ).strip()
    if item_id != 5 and len(address) < 5:
        raise ValueError("Укажите адрес")
    existing_customer_notes = order["customer_notes"] or v14.customer_note_from_order(order["notes"] or "")
    customer_notes = ((data.get("notes") if "notes" in data else existing_customer_notes) or "").strip()[:1200]
    notes = customer_notes
    target = order["executor_id"] or order["target_executor_id"]
    ep = None
    if target:
        ep = c.execute(
            "SELECT * FROM executor_profiles WHERE user_id=? AND active=1", (target,)
        ).fetchone()
        if not ep:
            raise ValueError("Исполнитель больше недоступен")
        reason = executor_slot_reason(
            c, int(target), date_str, time_str, duration, order["id"]
        )
        if reason:
            raise ValueError(reason)
    item = next((x for x in base.CATALOG if int(x["id"]) == item_id), None)
    if item_id == 2:
        try:
            categories = data.get("boarding_pet_categories")
            if not isinstance(categories, dict):
                categories = json.loads(order["pet_categories_json"] or "{}")
        except (TypeError, ValueError, json.JSONDecodeError):
            categories = {}
        categories = categories if isinstance(categories, dict) else {}
        categories = {str(pid): str(categories.get(str(pid), "small")) for pid in pet_ids}
        if any(value not in {"small", "medium"} for value in categories.values()):
            raise ValueError("Выберите тариф для каждого питомца")
        executor_rate = int(ep["price"] or 0) if ep else 0
        rates = [max(executor_rate, 3000 if categories[str(pid)] == "medium" else 2500) for pid in pet_ids]
        price = v14.calc_boarding_price(duration, rates)
        labels = [f"{row['name']} — {'средняя собака' if categories[str(row['id'])] == 'medium' else 'кошка/небольшая собака'}" for row in pets]
        if len(pet_ids) > 1:
            discount_label = "Семейная скидка 20%" if duration >= 21600 else "Семейная скидка 15%"
        else:
            discount_label = "Скидка 15%" if duration >= 43200 else "Скидка 10%" if duration >= 21600 else "Без скидки за длительность"
        notes = f"Передержка: {'; '.join(labels)}. {discount_label}. {customer_notes}".strip()[:1200]
    else:
        executor_base = max(int(ep["price"] or 0), int(item["price"])) if ep and item else int(order["price"] or 0)
        price = v14.calc_price(item_id, duration, executor_base)
    changed = (
        date_str != (order["scheduled_date"] or "")
        or time_str != (order["scheduled_time"] or "")
        or duration != int(order["duration_min"] or 60)
    )
    try:
        old_pet_ids = [int(x) for x in json.loads(order["pet_ids_json"] or "[]")]
    except (TypeError, ValueError, json.JSONDecodeError):
        old_pet_ids = [int(order["pet_id"] or 0)]
    try:
        old_categories = json.loads(order["pet_categories_json"] or "{}")
    except (TypeError, ValueError, json.JSONDecodeError):
        old_categories = {}
    details_changed = item_id == 2 and (
        pet_ids != old_pet_ids
        or categories != {str(pid): str(old_categories.get(str(pid), "small")) for pid in old_pet_ids}
    )
    if changed and not v14.request_date_allowed(date_str):
        raise ValueError("Перенести заказ можно минимум на завтра.")
    return {
        "scheduled_date": date_str,
        "scheduled_time": time_str,
        "duration_min": duration,
        "pet_id": pet_id,
        "pet_name": ", ".join(str(row["name"]) for row in pets),
        "pet_ids_json": json.dumps(pet_ids),
        "pet_categories_json": json.dumps(categories if item_id == 2 else {}, ensure_ascii=False),
        "address": address,
        "notes": notes,
        "customer_notes": customer_notes,
        "price": price,
        "schedule_changed": changed,
        "details_changed": details_changed,
        "requires_reconfirm": changed or details_changed,
        "target_executor_id": target,
    }


class Handler(v14.Handler):
    def serve_file(self, path, cache=False):
        if Path(path).name == "index.html":
            text = Path(path).read_text(encoding="utf-8")
            for href in (
                "/assets/app-v13.css?v=13",
                "/assets/app-v14.css?v=23",
                "/assets/app-v15.css?v=23",
                "/assets/app-v16.css?v=16",
                "/assets/app-v21.css?v=21",
            ):
                if href not in text:
                    text = text.replace(
                        "</head>", f'<link rel="stylesheet" href="{href}">\n</head>'
                    )
            for src in (
                "/assets/app-v13.js?v=13",
                "/assets/app-v14.js?v=23",
                "/assets/app-v15.js?v=23",
                "/assets/app-v16.js?v=16",
                "/assets/app-v21.js?v=21",
            ):
                if src not in text:
                    text = text.replace(
                        "</body>", f'<script src="{src}"></script>\n</body>'
                    )
            return v14.serve_bytes(self, text.encode(), "text/html; charset=utf-8")
        return super().serve_file(path, cache=False)

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        q = urllib.parse.parse_qs(parsed.query)
        if path == "/health":
            return self.send_json(
                {
                    "status": "ok",
                    "test_mode": base.TEST_MODE,
                    "ui": "premium-v23.1",
                    "persistent_db": str(base.DB).startswith("/data/"),
                }
            )
        if path == "/api/executor/application":
            user = self.require_user()
            if not user:
                return
            uid = int(user["id"])
            c = base.conn()
            row = c.execute(
                "SELECT data_json,status,created_at,updated_at FROM executor_applications WHERE user_id=?",
                (uid,),
            ).fetchone()
            c.close()
            if not row:
                return self.send_json({"data": {}, "status": "new"})
            try:
                data = json.loads(row["data_json"] or "{}")
            except Exception:
                data = {}
            return self.send_json({
                "data": data,
                "status": row["status"] or "submitted",
                "created_at": row["created_at"],
                "updated_at": row["updated_at"],
            })

        if path == "/api/site-requests":
            user = self.require_user()
            if not user:
                return
            uid = int(user["id"])
            c = base.conn()
            profile = c.execute("""SELECT ep.services_json,ep.city,ep.area FROM executor_profiles ep JOIN users u ON u.id=ep.user_id
                WHERE ep.user_id=? AND ep.active=1 AND COALESCE(u.executor_enabled,0)=1""", (uid,)).fetchone()
            if not profile:
                c.close()
                return self.send_json({"error": "Доступно исполнителям с активным профилем"}, 403)
            try:
                services = {int(x) for x in json.loads(profile["services_json"] or "[]")}
            except (ValueError, TypeError):
                services = set()
            rows = c.execute("SELECT * FROM site_requests WHERE status IN ('new','contacted','matching') ORDER BY scheduled_date,scheduled_time,site_request_id DESC LIMIT 100").fetchall()
            results = []
            for row in rows:
                service_id = SITE_SERVICE_IDS.get(row["service"])
                if service_id and services and service_id not in services:
                    continue
                requested_city = {"spb": "Санкт-Петербург", "msk": "Москва"}.get(row["city"], row["city"])
                if requested_city and profile["city"] and requested_city != profile["city"]:
                    continue
                prior = c.execute("SELECT sync_status,sync_attempts FROM site_request_interests WHERE site_request_id=? AND executor_id=?", (row["site_request_id"], uid)).fetchone()
                results.append({"id": int(row["site_request_id"]), "service": row["service"], "city": requested_city,
                    "district": row["district"], "date": row["scheduled_date"], "time": row["scheduled_time"],
                    "duration_min": int(row["duration_min"] or 60), "sla_minutes": int(row["sla_minutes"] or 0),
                    "already_interested": bool(prior), "interest_synced": bool(prior and prior["sync_status"] == "sent"),
                    "interest_sync_status": prior["sync_status"] if prior else "",
                    "interest_sync_attempts": int(prior["sync_attempts"] or 0) if prior else 0})
            c.close()
            return self.send_json({"requests": results, "source": "website", "read_only": True})

        if path.startswith("/api/executors/") and path.endswith("/slots"):
            user = self.require_user()
            if not user:
                return
            parts = path.strip("/").split("/")
            try:
                executor_id = int(parts[2])
            except Exception:
                return self.send_json({"error": "Исполнитель не найден"}, 404)
            date_str = (q.get("date") or [""])[0]
            try:
                duration = max(
                    30, min(43200, int((q.get("duration") or [60])[0]))
                )
            except Exception:
                duration = 60
            try:
                exclude_order_id = (
                    int((q.get("exclude_order_id") or [0])[0]) or None
                )
            except Exception:
                exclude_order_id = None
            try:
                datetime.fromisoformat(date_str)
            except Exception:
                return self.send_json({"error": "Укажите дату"}, 400)
            c = base.conn()
            if not c.execute(
                "SELECT 1 FROM executor_profiles WHERE user_id=? AND active=1",
                (executor_id,),
            ).fetchone():
                c.close()
                return self.send_json({"error": "Исполнитель недоступен"}, 404)
            slots = []
            for minute in range(SLOT_START_MIN, SLOT_END_MIN + 1, SLOT_STEP_MIN):
                t = minute_to_time(minute)
                reason = executor_slot_reason(
                    c,
                    executor_id,
                    date_str,
                    t,
                    duration,
                    exclude_order_id,
                )
                slots.append(
                    {"time": t, "available": not bool(reason), "reason": reason}
                )
            c.close()
            return self.send_json(
                {"date": date_str, "duration_min": duration, "slots": slots}
            )
        return super().do_GET()

    def do_POST(self):
        path = urllib.parse.urlparse(self.path).path
        if path == "/integrations/walkie/site-ping":
            try:
                length = int(self.headers.get("Content-Length", "0") or 0)
            except ValueError:
                length = 0
            if length < 1 or length > 8192:
                return self.send_json({"error": "Размер проверки вне лимита"}, 413)
            raw = self.rfile.read(length)
            result = process_site_ping(raw, self.headers.get("X-Walkie-Signature", ""))
            if not result.get("ok"):
                return self.send_json({"error": result.get("error", "Проверка отклонена")}, int(result.get("status", 400)))
            return self.send_json({"ok": True, "event": result["event"], "nonce": result["nonce"]})
        if path == "/integrations/walkie/site-event":
            try:
                length = int(self.headers.get("Content-Length", "0") or 0)
            except ValueError:
                length = 0
            if length < 1 or length > 32768:
                return self.send_json({"error": "Размер события вне лимита"}, 413)
            raw = self.rfile.read(length)
            result = process_site_webhook(raw, self.headers.get("X-Walkie-Signature", ""))
            if not result.get("ok"):
                return self.send_json({"error": result.get("error", "Событие отклонено")}, int(result.get("status", 400)))
            if result.get("notify_unassigned"):
                self.notify_site_executors(result)
            return self.send_json({"ok": True, "id": result["id"], "stale": bool(result.get("stale")), "duplicate": bool(result.get("duplicate"))})
        if path.startswith("/api/site-requests/") and path.endswith("/interest"):
            user = self.require_user()
            if not user:
                return
            parts = path.strip("/").split("/")
            try:
                site_id = int(parts[2])
            except (IndexError, ValueError):
                return self.send_json({"error": "Заявка не найдена"}, 404)
            uid = int(user["id"])
            c = base.conn()
            profile = c.execute("""SELECT ep.display_name,ep.services_json,ep.city,ep.area FROM executor_profiles ep JOIN users u ON u.id=ep.user_id
                WHERE ep.user_id=? AND ep.active=1 AND COALESCE(u.executor_enabled,0)=1""", (uid,)).fetchone()
            order = c.execute("SELECT * FROM site_requests WHERE site_request_id=? AND status IN ('new','contacted','matching')", (site_id,)).fetchone()
            if not profile or not order:
                c.close()
                return self.send_json({"error": "Заявка больше недоступна"}, 409)
            service_id = SITE_SERVICE_IDS.get(order["service"])
            try:
                services = {int(x) for x in json.loads(profile["services_json"] or "[]")}
            except (ValueError, TypeError):
                services = set()
            wanted_city = {"spb": "Санкт-Петербург", "msk": "Москва"}.get(order["city"], order["city"])
            if (service_id and services and service_id not in services) or (wanted_city and profile["city"] and wanted_city != profile["city"]):
                c.close()
                return self.send_json({"error": "Заявка не подходит по услуге или городу"}, 403)
            cur = c.execute("INSERT OR IGNORE INTO site_request_interests(site_request_id,executor_id,created_at) VALUES(?,?,?)", (site_id, uid, v14.now_iso()))
            c.commit()
            c.close()
            delivery = deliver_site_interest(site_id, uid, profile, order["service"])
            site_synced = delivery["site_synced"]
            if cur.rowcount:
                self.notify_site_managers(site_id, profile, order, site_synced)
            return self.send_json({"ok": True, "already": not bool(cur.rowcount), "site_synced":site_synced,
                "sync_status":delivery["sync_status"], "sync_attempts":delivery["sync_attempts"],
                "message": "Отклик записан в CRM сайта." if site_synced else "Отклик сохранён в приложении. CRM сайта пока не подтвердила получение — повторите передачу."})
        if path == "/api/executor/application":
            user = self.require_user()
            if not user:
                return
            uid = int(user["id"])
            data = self.read_json()

            if bool(data.get("_draft")):
                allowed = {
                    "full_name","age","primary_activity","city","preferred_areas","phone",
                    "telegram_username","social_url","self_employed_status","self_employed_help",
                    "services","animals","restrictions","experience_years","education","recent_courses",
                    "service_location","separate_room","simultaneous_pets","contract_ready","urgent_orders",
                    "anxious_experience","first_aid","emergency_response","reports_geo","work_days",
                    "work_hours","weekends","holidays","standards_agreement","cooperation_priorities",
                    "extra_info","own_pet","_last_step"
                }
                draft = {k: data.get(k) for k in allowed if k in data}
                payload = json.dumps(draft, ensure_ascii=False)
                if len(payload.encode("utf-8")) > 30000:
                    return self.send_json({"error": "Анкета слишком большая"}, 400)
                c = base.conn()
                row = c.execute(
                    "SELECT status,created_at FROM executor_applications WHERE user_id=?",
                    (uid,),
                ).fetchone()
                stamp = v14.now_iso()
                status = "submitted" if row and row["status"] == "submitted" else "draft"
                created = row["created_at"] if row and row["created_at"] else stamp
                c.execute(
                    """INSERT INTO executor_applications(user_id,data_json,status,created_at,updated_at)
                       VALUES(?,?,?,?,?)
                       ON CONFLICT(user_id) DO UPDATE SET
                         data_json=excluded.data_json,
                         status=excluded.status,
                         updated_at=excluded.updated_at""",
                    (uid, payload, status, created, stamp),
                )
                c.commit()
                c.close()
                return self.send_json({"ok": True, "status": status, "updated_at": stamp})

            def s(key, limit=500):
                return str(data.get(key) or "").strip()[:limit]

            full_name = s("full_name", 120)
            try:
                age = int(data.get("age") or 0)
            except Exception:
                age = 0
            primary_activity = s("primary_activity", 80)
            city = s("city", 80)
            preferred_areas = s("preferred_areas", 180)
            phone = s("phone", 30)
            telegram_username = s("telegram_username", 80)
            phone_digits = "".join(ch for ch in phone if ch.isdigit())

            services = data.get("services") or []
            valid_services = sorted({
                int(x) for x in services
                if str(x).isdigit() and 1 <= int(x) <= 8
            })
            work_days = [
                str(x) for x in (data.get("work_days") or [])
                if str(x) in ("Пн","Вт","Ср","Чт","Пт","Сб","Вс")
            ]
            try:
                experience_years = max(0.0, min(50.0, float(data.get("experience_years") or 0)))
            except Exception:
                experience_years = 0.0
            try:
                simultaneous_pets = max(1, min(20, int(data.get("simultaneous_pets") or 1)))
            except Exception:
                simultaneous_pets = 1

            if len(full_name) < 5:
                return self.send_json({"error": "Укажите ФИО"}, 400)
            if age < 18 or age > 80:
                return self.send_json({"error": "Укажите корректный возраст (18+)"}, 400)
            if not primary_activity:
                return self.send_json({"error": "Выберите основную деятельность"}, 400)
            if city not in v14.RUS_CITIES:
                return self.send_json({"error": "Выберите город из списка"}, 400)
            if len(preferred_areas) < 2:
                return self.send_json({"error": "Укажите районы работы"}, 400)
            if len(phone_digits) < 10:
                return self.send_json({"error": "Укажите контактный телефон"}, 400)
            if len(telegram_username) < 2:
                return self.send_json({"error": "Укажите Telegram"}, 400)
            if not valid_services:
                return self.send_json({"error": "Выберите хотя бы одну услугу"}, 400)
            if not s("animals", 220):
                return self.send_json({"error": "Укажите, с какими животными работаете"}, 400)
            if not s("service_location", 120):
                return self.send_json({"error": "Укажите формат оказания услуг"}, 400)
            if len(s("emergency_response", 700)) < 10:
                return self.send_json({"error": "Опишите действия в экстренной ситуации"}, 400)
            if not work_days or not s("work_hours", 120):
                return self.send_json({"error": "Заполните график работы"}, 400)
            if s("standards_agreement", 16) != "Да":
                return self.send_json({"error": "Для работы нужно согласиться соблюдать стандарты сервиса"}, 400)

            clean = {
                "full_name": full_name,
                "age": age,
                "primary_activity": primary_activity,
                "city": city,
                "preferred_areas": preferred_areas,
                "phone": phone,
                "telegram_username": telegram_username,
                "social_url": s("social_url", 300),
                "self_employed_status": s("self_employed_status", 40),
                "self_employed_help": s("self_employed_help", 16),
                "services": valid_services,
                "animals": s("animals", 220),
                "restrictions": s("restrictions", 500),
                "experience_years": experience_years,
                "education": s("education", 300),
                "recent_courses": s("recent_courses", 500),
                "service_location": s("service_location", 120),
                "separate_room": s("separate_room", 16),
                "simultaneous_pets": simultaneous_pets,
                "contract_ready": s("contract_ready", 16),
                "urgent_orders": s("urgent_orders", 16),
                "anxious_experience": s("anxious_experience", 16),
                "first_aid": s("first_aid", 16),
                "emergency_response": s("emergency_response", 700),
                "reports_geo": s("reports_geo", 16),
                "work_days": work_days,
                "work_hours": s("work_hours", 120),
                "weekends": s("weekends", 16),
                "holidays": s("holidays", 16),
                "standards_agreement": "Да",
                "cooperation_priorities": s("cooperation_priorities", 700),
                "extra_info": s("extra_info", 700),
                "own_pet": s("own_pet", 220),
            }

            c = base.conn()
            v14.upsert_executor(c, user)
            years_label = (
                "Без коммерческого опыта"
                if experience_years == 0
                else f"{experience_years:g} года опыта"
            )
            experience = f"{years_label} · {clean['animals']}"[:160]
            about_parts = [
                primary_activity,
                clean["cooperation_priorities"],
                clean["extra_info"],
            ]
            bio = " · ".join(x for x in about_parts if x)[:800]
            c.execute(
                """UPDATE executor_profiles SET
                   display_name=?,city=?,area=?,experience=?,bio=?,services_json=?,
                   active=1,onboarding_complete=1
                   WHERE user_id=?""",
                (
                    full_name, city, preferred_areas, experience, bio,
                    json.dumps(valid_services, ensure_ascii=False), uid,
                ),
            )
            stamp = v14.now_iso()
            c.execute(
                """INSERT INTO executor_applications(user_id,data_json,status,created_at,updated_at)
                   VALUES(?,?,?,?,?)
                   ON CONFLICT(user_id) DO UPDATE SET
                     data_json=excluded.data_json,
                     status=excluded.status,
                     updated_at=excluded.updated_at""",
                (
                    uid,
                    json.dumps(clean, ensure_ascii=False),
                    "submitted",
                    stamp,
                    stamp,
                ),
            )
            c.execute(
                "UPDATE users SET role='executor',executor_enabled=1,city=? WHERE id=?",
                (city, uid),
            )
            c.commit()
            c.close()
            return self.send_json({
                "ok": True,
                "role": "executor",
                "status": "submitted",
                "onboarding_complete": True,
            })

        if path.startswith("/api/orders/") and path.endswith("/edit"):
            user = self.require_user()
            if not user:
                return
            uid = int(user["id"])
            oid = parse_order_id(path, "edit")
            if not oid:
                return self.send_json({"error": "Заказ не найден"}, 404)
            data = self.read_json()
            c = base.conn()
            order = c.execute(
                "SELECT * FROM orders WHERE id=? AND user_id=?", (oid, uid)
            ).fetchone()
            if not order:
                c.close()
                return self.send_json({"error": "Заказ не найден"}, 404)
            if order["status"] not in ("open", "accepted"):
                c.close()
                return self.send_json(
                    {"error": "Этот заказ уже нельзя изменить"}, 409
                )
            try:
                p = order_edit_payload(c, uid, order, data)
            except ValueError as exc:
                c.close()
                return self.send_json({"error": str(exc)}, 409)
            old_status = order["status"]
            target = p["target_executor_id"]
            new_status = old_status
            executor_id = order["executor_id"]
            accepted_at = order["accepted_at"]
            event_text = "Клиент изменил параметры заказа"
            if old_status == "accepted" and p["requires_reconfirm"]:
                new_status = "open"
                executor_id = None
                accepted_at = None
                event_text = (
                    "Клиент изменил дату или время. "
                    "Исполнителю нужно подтвердить заказ заново"
                )
            c.execute(
                """UPDATE orders SET
                scheduled_date=?,scheduled_time=?,duration_min=?,pet_id=?,pet_name=?,pet_ids_json=?,pet_categories_json=?,
                address=?,notes=?,customer_notes=?,price=?,status=?,executor_id=?,target_executor_id=?,
                accepted_at=?,updated_at=? WHERE id=?""",
                (
                    p["scheduled_date"],
                    p["scheduled_time"],
                    p["duration_min"],
                    p["pet_id"],
                    p["pet_name"],
                    p["pet_ids_json"],
                    p["pet_categories_json"],
                    p["address"],
                    p["notes"],
                    p["customer_notes"],
                    p["price"],
                    new_status,
                    executor_id,
                    target,
                    accepted_at,
                    v14.now_iso(),
                    oid,
                ),
            )
            v14.add_event(c, oid, uid, "edited", event_text)
            c.commit()
            c.close()
            if target:
                v14.notify_user(
                    target,
                    f"Заказ №{oid} изменён: {p['scheduled_date']} {p['scheduled_time']}"
                    + (
                        " · требуется повторное подтверждение"
                        if new_status == "open"
                        else ""
                    ),
                )
            return self.send_json(
                {
                    "ok": True,
                    "id": oid,
                    "status": new_status,
                    "price": p["price"],
                    "requires_reconfirm": old_status == "accepted"
                    and p["requires_reconfirm"],
                }
            )
        return super().do_POST()

    def notify_site_managers(self, site_id, profile, order, site_synced=False):
        if not base.BOT_TOKEN or not MANAGER_TELEGRAM_IDS:
            return
        text = (f"Walkie · отклик на заявку сайта #{site_id}\n{profile['display_name']} · {profile['city']} / {profile['area']}\n"
                f"{order['service']} · {order['scheduled_date']} {order['scheduled_time']}\nCRM сайта: {'отклик записан' if site_synced else 'не подключена, отклик сохранён в боте'}. Назначение подтвердите в CRM сайта.")
        for manager_id in MANAGER_TELEGRAM_IDS:
            threading.Thread(target=lambda chat_id=manager_id: base.telegram("sendMessage", {"chat_id": int(chat_id), "text": text}), daemon=True).start()

    def notify_site_executors(self, event):
        if not base.BOT_TOKEN:
            return
        c = base.conn()
        order = c.execute("SELECT * FROM site_requests WHERE site_request_id=?", (int(event["id"]),)).fetchone()
        if not order:
            c.close()
            return
        service_id = SITE_SERVICE_IDS.get(order["service"])
        rows = c.execute("""SELECT ep.user_id,ep.services_json,ep.city FROM executor_profiles ep JOIN users u ON u.id=ep.user_id
            WHERE ep.active=1 AND COALESCE(u.executor_enabled,0)=1""").fetchall()
        c.close()
        city = {"spb": "Санкт-Петербург", "msk": "Москва"}.get(order["city"], order["city"])
        text = (f"Walkie · заявка с сайта #{order['site_request_id']} пока без исполнителя ({int(event.get('minutes') or 20)} мин).\n"
                f"{order['service']} · {city} / {order['district'] or 'район уточняется'} · {order['scheduled_date']} {order['scheduled_time']}\n"
                "Контакты владельца скрыты. Откройте приложение Walkie → Заявки → С сайта, чтобы откликнуться.")
        for row in rows:
            try:
                services = {int(x) for x in json.loads(row["services_json"] or "[]")}
            except (ValueError, TypeError):
                services = set()
            if service_id and services and service_id not in services:
                continue
            if city and row["city"] and city != row["city"]:
                continue
            threading.Thread(target=lambda chat_id=int(row["user_id"]): base.telegram("sendMessage", {"chat_id": chat_id, "text": text}), daemon=True).start()


if __name__ == "__main__":
    init_v15()
    threading.Thread(
        target=lambda: (time.sleep(1.2), base.configure_bot()), daemon=True
    ).start()
    print("listening v23.1", base.PORT, "db", base.DB)
    base.ThreadingHTTPServer(("0.0.0.0", base.PORT), Handler).serve_forever()
