import os
import sqlite3
import tempfile
import unittest
from datetime import date, timedelta

os.environ["DB_PATH"] = os.path.join(tempfile.gettempdir(), "walkie-tariff-test.sqlite3")
os.environ["TEST_MODE"] = "true"

import app_v14
import app_v15


class ServiceTariffTests(unittest.TestCase):
    def test_core_catalog_uses_current_service_document_prices(self):
        prices = {item["id"]: item["price"] for item in app_v14.base.CATALOG}
        self.assertEqual(prices[1], 1500)  # 60-minute walk
        self.assertEqual(prices[2], 2500)  # boarding, cat/small pet, per day
        self.assertEqual(prices[3], 1000)  # home visit, 30 minutes
        self.assertEqual(prices[4], 2000)  # introductory training price

    def test_boarding_price_is_per_day_and_applies_documented_stay_discounts(self):
        expected = {1440: 2500, 2880: 5000, 10080: 17500, 20160: 35000, 21600: 33750, 43200: 63750}
        for duration, price in expected.items():
            with self.subTest(days=duration // 1440):
                self.assertEqual(app_v14.calc_price(2, duration), price)
        self.assertEqual(app_v14.calc_price(2, 9 * 1440), 22500)

    def test_multi_pet_boarding_cart_applies_family_discount_and_each_pet_rate(self):
        self.assertEqual(app_v14.calc_boarding_price(1440, [2500, 3000]), 4675)
        self.assertEqual(app_v14.calc_boarding_price(14 * 1440, [2500, 3000]), 65450)
        self.assertEqual(app_v14.calc_boarding_price(15 * 1440, [2500, 3000]), 66000)
        self.assertEqual(app_v14.calc_boarding_price(15 * 1440, [2500]), 33750)
        self.assertEqual(app_v14.calc_boarding_price(30 * 1440, [2500]), 63750)
        self.assertEqual(app_v14.calc_boarding_price(13 * 1440, [2500]), 32500)
        self.assertEqual(app_v14.calc_boarding_price(60, [2500]), 0)

    def test_sitter_price_is_1000_per_30_minutes(self):
        self.assertEqual(app_v14.calc_price(3, 30), 1000)
        self.assertEqual(app_v14.calc_price(3, 60), 2000)

    def test_editing_boarding_basket_reprices_and_requires_reconfirmation(self):
        c = sqlite3.connect(':memory:')
        c.row_factory = sqlite3.Row
        c.execute('CREATE TABLE pets (id INTEGER PRIMARY KEY,user_id INTEGER,name TEXT)')
        c.executemany('INSERT INTO pets VALUES(?,?,?)', [(1,7,'Бакс'),(2,7,'Луна'),(3,7,'Чарли')])
        tomorrow = (date.today() + timedelta(days=3)).isoformat()
        order = {'id':41,'item_id':2,'scheduled_date':tomorrow,'scheduled_time':'12:00',
                 'duration_min':14*1440,'pet_id':1,'pet_ids_json':'[1,2]',
                 'pet_categories_json':'{"1":"small","2":"medium"}',
                 'address':'Лесная, 10','notes':'Передержка: Бакс. Семейная скидка 15%. заметка','customer_notes':'заметка','executor_id':None,
                 'target_executor_id':None,'price':65450}
        result = app_v15.order_edit_payload(c,7,order,{
            'scheduled_date':tomorrow,'scheduled_time':'12:00','duration_min':14*1440,
            'pet_id':1,'pet_ids':[1,3],'boarding_pet_categories':{'1':'medium','3':'small'},
            'address':'Лесная, 10','notes':''
        })
        self.assertEqual(result['pet_name'],'Бакс, Чарли')
        self.assertEqual(result['price'],65450)
        self.assertIn('Бакс — средняя собака; Чарли — кошка/небольшая собака',result['notes'])
        self.assertIn('Семейная скидка 15%',result['notes'])
        self.assertEqual(result['customer_notes'],'')
        self.assertTrue(result['details_changed'])
        self.assertTrue(result['requires_reconfirm'])
        c.close()

    def test_editing_boarding_rejects_pet_from_another_account(self):
        c = sqlite3.connect(':memory:')
        c.row_factory = sqlite3.Row
        c.execute('CREATE TABLE pets (id INTEGER PRIMARY KEY,user_id INTEGER,name TEXT)')
        c.executemany('INSERT INTO pets VALUES(?,?,?)', [(1,7,'Бакс'),(9,8,'Чужой')])
        tomorrow = (date.today() + timedelta(days=3)).isoformat()
        order = {'id':42,'item_id':2,'scheduled_date':tomorrow,'scheduled_time':'12:00',
                 'duration_min':1440,'pet_id':1,'pet_ids_json':'[1]',
                 'pet_categories_json':'{"1":"small"}','address':'Лесная, 10',
                 'notes':'','customer_notes':'','executor_id':None,'target_executor_id':None,'price':2500}
        with self.assertRaisesRegex(ValueError,'Питомец не найден'):
            app_v15.order_edit_payload(c,7,order,{
                'scheduled_date':tomorrow,'scheduled_time':'12:00','duration_min':1440,
                'pet_id':9,'pet_ids':[9],'boarding_pet_categories':{'9':'small'},
                'address':'Лесная, 10','notes':''
            })
        c.close()

    def test_existing_order_schema_migrates_with_single_pet_defaults(self):
        c = sqlite3.connect(':memory:')
        c.row_factory = sqlite3.Row
        c.execute('CREATE TABLE orders (id INTEGER PRIMARY KEY)')
        app_v14.ensure_column(c,'orders','pet_ids_json',"TEXT NOT NULL DEFAULT ''")
        app_v14.ensure_column(c,'orders','pet_categories_json',"TEXT NOT NULL DEFAULT ''")
        app_v14.ensure_column(c,'orders','customer_notes',"TEXT NOT NULL DEFAULT ''")
        c.execute('INSERT INTO orders(id) VALUES(1)')
        row = c.execute('SELECT pet_ids_json,pet_categories_json,customer_notes FROM orders WHERE id=1').fetchone()
        self.assertEqual(row['pet_ids_json'],'')
        self.assertEqual(row['pet_categories_json'],'')
        self.assertEqual(row['customer_notes'],'')
        c.close()

    def test_legacy_system_tariff_note_can_be_cleaned_for_editing(self):
        self.assertEqual(app_v14.customer_note_from_order('Передержка: Бакс. Семейная скидка 15%. За воротами звонить.'),'За воротами звонить.')
        self.assertEqual(app_v14.customer_note_from_order('Обычная прогулка: ждать у подъезда'),'Обычная прогулка: ждать у подъезда')


if __name__ == "__main__":
    unittest.main()
