import hashlib
import hmac
import json
import os
import tempfile
import unittest
from datetime import date
from unittest.mock import patch

DB_PATH = os.path.join(tempfile.gettempdir(), "walkie-site-sync-test.sqlite3")
os.environ["DB_PATH"] = DB_PATH
os.environ["TEST_MODE"] = "true"

import app_v14
import app_v15


class RequestDateTests(unittest.TestCase):
    def test_request_date_must_be_after_moscow_today(self):
        today = date(2026, 10, 17)
        self.assertFalse(app_v14.request_date_allowed("2026-10-17", today))
        self.assertTrue(app_v14.request_date_allowed("2026-10-18", today))
        self.assertFalse(app_v14.request_date_allowed("not-a-date", today))


class SiteSyncTests(unittest.TestCase):
    def signed(self, payload, secret="site-secret"):
        raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode()
        signature = "sha256=" + hmac.new(secret.encode(), raw, hashlib.sha256).hexdigest()
        return raw, signature

    def test_webhook_signature_is_required(self):
        raw, _ = self.signed({"event":"walkie.request.created","id":913,"data":{}})
        result = app_v15.process_site_webhook(raw, "", "site-secret")
        self.assertEqual(result["status"], 401)

    def test_signed_integration_ping_does_not_write_a_request(self):
        app_v15.init_v15()
        payload = {"event":"walkie.integration.ping","nonce":"diagnostics-123","occurred_at":app_v15.v14.now_iso()}
        raw, signature = self.signed(payload)
        before = app_v15.base.conn().execute("SELECT COUNT(*) FROM site_requests").fetchone()[0]
        result = app_v15.process_site_ping(raw, signature, "site-secret")
        after = app_v15.base.conn().execute("SELECT COUNT(*) FROM site_requests").fetchone()[0]
        self.assertEqual(result, {"ok":True,"event":"walkie.integration.ping","nonce":"diagnostics-123"})
        self.assertEqual(after, before)
        self.assertEqual(app_v15.process_site_ping(raw, "sha256=bad", "site-secret")["status"], 401)

    def test_executor_interest_callback_is_signed_and_contains_no_customer_contact(self):
        old_secret, old_url = app_v15.WALKIE_SITE_WEBHOOK_SECRET, app_v15.WALKIE_SITE_CALLBACK_URL
        app_v15.WALKIE_SITE_WEBHOOK_SECRET = "site-secret"
        app_v15.WALKIE_SITE_CALLBACK_URL = "https://site.example.invalid/wp-json/walkie/v1/bot-interest"
        class Response:
            status = 200
            def __enter__(self): return self
            def __exit__(self, *_): return False
            def read(self, _): return b'{"ok":true}'
        sent = []
        class Opener:
            def open(self, request, timeout):
                sent.append((request, timeout))
                return Response()
        try:
            with patch("app_v15.urllib.request.build_opener", return_value=Opener()):
                self.assertTrue(app_v15.push_site_interest(913, 42, "Исполнитель", "Санкт-Петербург", "Центральный", "walk"))
                request = sent[0][0]
                body = json.loads(request.data.decode())
                expected = "sha256=" + hmac.new(b"site-secret", request.data, hashlib.sha256).hexdigest()
                self.assertEqual(request.get_header("X-walkie-signature"), expected)
                self.assertEqual(body["event"], "walkie.executor.interested")
                self.assertNotIn("phone", body)
                self.assertNotIn("email", body)
        finally:
            app_v15.WALKIE_SITE_WEBHOOK_SECRET, app_v15.WALKIE_SITE_CALLBACK_URL = old_secret, old_url

    def test_site_request_upsert_is_idempotent_and_ignores_stale_event(self):
        app_v15.init_v15()
        payload = {"event":"walkie.request.created","id":913,"occurred_at":"2026-10-17T12:00:00+00:00",
                   "data":{"service":"walk","city":"spb","district":"Центральный","date":"2026-10-19","time":"10:30","duration":60,"status":"new"}}
        raw, signature = self.signed(payload)
        self.assertTrue(app_v15.process_site_webhook(raw, signature, "site-secret")["ok"])
        self.assertTrue(app_v15.process_site_webhook(raw, signature, "site-secret")["duplicate"])
        stale = dict(payload, occurred_at="2026-10-17T11:00:00+00:00")
        stale["data"] = dict(payload["data"], district="старый район")
        raw_stale, signature_stale = self.signed(stale)
        self.assertTrue(app_v15.process_site_webhook(raw_stale, signature_stale, "site-secret")["stale"])
        c = app_v15.base.conn()
        rows = c.execute("SELECT * FROM site_requests WHERE site_request_id=913").fetchall()
        c.close()
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["district"], "Центральный")
        self.assertEqual(rows[0]["service"], "walk")

    def test_executor_assignment_event_closes_open_feed_record(self):
        app_v15.init_v15()
        created = {"event":"walkie.request.created","id":914,"occurred_at":"2026-10-17T12:00:00+00:00",
                   "data":{"service":"walk","city":"spb","date":"2026-10-19","time":"10:30","status":"matching"}}
        raw, sig = self.signed(created)
        self.assertTrue(app_v15.process_site_webhook(raw, sig, "site-secret")["ok"])
        assigned = {"event":"walkie.request.executor_assigned","id":914,"occurred_at":"2026-10-17T12:05:00+00:00",
                    "data":{"executor_id":42}}
        raw, sig = self.signed(assigned)
        self.assertTrue(app_v15.process_site_webhook(raw, sig, "site-secret")["ok"])
        c = app_v15.base.conn()
        row = c.execute("SELECT status,assigned_executor_id FROM site_requests WHERE site_request_id=914").fetchone()
        open_count = c.execute("SELECT COUNT(*) FROM site_requests WHERE site_request_id=914 AND status IN ('new','contacted','matching')").fetchone()[0]
        c.close()
        self.assertEqual((row["status"], row["assigned_executor_id"]), ("assigned", 42))
        self.assertEqual(open_count, 0)

    def test_retried_unassigned_event_does_not_repeat_executor_alert(self):
        app_v15.init_v15()
        c = app_v15.base.conn()
        c.execute("DELETE FROM site_request_interests WHERE site_request_id=916")
        c.execute("DELETE FROM site_requests WHERE site_request_id=916")
        c.commit(); c.close()
        def event(name, stamp, status, minutes=0):
            payload = {"event":name,"id":916,"occurred_at":stamp,
                       "data":{"service":"walk","city":"spb","status":status,"minutes":minutes}}
            raw, signature = self.signed(payload)
            return app_v15.process_site_webhook(raw,signature,"site-secret")
        created = event("walkie.request.created","2026-10-17T12:00:00+00:00","matching")
        first = event("walkie.request.unassigned","2026-10-17T12:20:00+00:00","matching",20)
        retry = event("walkie.request.unassigned","2026-10-17T12:21:00+00:00","matching",20)
        self.assertTrue(created["ok"])
        self.assertTrue(first["notify_unassigned"])
        self.assertFalse(retry["notify_unassigned"])
        reopened = event("walkie.request.status_changed","2026-10-17T12:22:00+00:00","matching")
        second_cycle = event("walkie.request.unassigned","2026-10-17T12:42:00+00:00","matching",20)
        self.assertTrue(reopened["ok"])
        self.assertTrue(second_cycle["notify_unassigned"])

    def test_interest_delivery_failure_is_retryable_and_idempotent(self):
        app_v15.init_v15()
        c = app_v15.base.conn()
        c.execute("INSERT OR REPLACE INTO site_request_interests(site_request_id,executor_id,created_at) VALUES(915,43,'2026-10-17T12:00:00+00:00')")
        c.commit()
        c.close()
        profile = {"display_name":"Исполнитель", "city":"Санкт-Петербург", "area":"Центральный"}
        with patch("app_v15.push_site_interest", return_value=False) as send:
            failed = app_v15.deliver_site_interest(915, 43, profile, "walk")
        self.assertEqual(failed["sync_status"], "failed")
        self.assertEqual(failed["sync_attempts"], 1)
        with patch("app_v15.push_site_interest", return_value=True) as send:
            sent = app_v15.deliver_site_interest(915, 43, profile, "walk")
        self.assertTrue(sent["site_synced"])
        self.assertEqual(sent["sync_attempts"], 2)
        with patch("app_v15.push_site_interest") as send:
            duplicate = app_v15.deliver_site_interest(915, 43, profile, "walk")
            send.assert_not_called()
        c = app_v15.base.conn()
        row = c.execute("SELECT sync_status,sync_attempts FROM site_request_interests WHERE site_request_id=915 AND executor_id=43").fetchone()
        c.close()
        self.assertEqual((row["sync_status"], row["sync_attempts"]), ("sent", 2))
        self.assertTrue(duplicate["site_synced"])

    def test_existing_site_sync_tables_gain_delivery_columns(self):
        old_db = app_v15.base.DB
        temp = tempfile.TemporaryDirectory(prefix="walkie-site-migration-")
        try:
            app_v15.base.DB = temp.name + "/legacy.sqlite3"
            app_v15.v14.init_v14()
            c = app_v15.base.conn()
            c.executescript("""
              CREATE TABLE site_requests(site_request_id INTEGER PRIMARY KEY,service TEXT NOT NULL DEFAULT '',city TEXT NOT NULL DEFAULT '',district TEXT NOT NULL DEFAULT '',scheduled_date TEXT NOT NULL DEFAULT '',scheduled_time TEXT NOT NULL DEFAULT '',duration_min INTEGER NOT NULL DEFAULT 60,status TEXT NOT NULL DEFAULT 'new',sla_minutes INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL DEFAULT '',updated_at TEXT NOT NULL DEFAULT '',last_event_at TEXT NOT NULL DEFAULT '',last_event_hash TEXT NOT NULL DEFAULT '');
              CREATE TABLE site_request_interests(id INTEGER PRIMARY KEY AUTOINCREMENT,site_request_id INTEGER NOT NULL,executor_id INTEGER NOT NULL,created_at TEXT NOT NULL,UNIQUE(site_request_id,executor_id));
              INSERT INTO site_requests(site_request_id,status) VALUES(44,'matching');
              INSERT INTO site_request_interests(site_request_id,executor_id,created_at) VALUES(44,7,'2026-10-17');
            """)
            c.commit(); c.close()
            app_v15.init_v15()
            c = app_v15.base.conn()
            request_cols = {r["name"] for r in c.execute("PRAGMA table_info(site_requests)")}
            interest_cols = {r["name"] for r in c.execute("PRAGMA table_info(site_request_interests)")}
            legacy = c.execute("SELECT assigned_executor_id FROM site_requests WHERE site_request_id=44").fetchone()
            interest = c.execute("SELECT sync_status,sync_attempts FROM site_request_interests WHERE site_request_id=44 AND executor_id=7").fetchone()
            c.close()
            self.assertTrue({"assigned_executor_id", "unassigned_notified_minutes"}.issubset(request_cols))
            self.assertTrue({"sync_status", "sync_attempts", "last_sync_at", "sync_error"}.issubset(interest_cols))
            self.assertEqual(legacy["assigned_executor_id"], 0)
            self.assertEqual((interest["sync_status"], interest["sync_attempts"]), ("pending", 0))
        finally:
            app_v15.base.DB = old_db
            temp.cleanup()


if __name__ == "__main__":
    unittest.main()
