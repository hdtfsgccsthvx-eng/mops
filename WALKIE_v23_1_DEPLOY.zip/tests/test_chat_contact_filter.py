import os
import tempfile
import unittest

DB_PATH = os.path.join(tempfile.gettempdir(), "walkie-contact-filter-test.sqlite3")
os.environ["DB_PATH"] = DB_PATH
os.environ["TEST_MODE"] = "true"

import app_v14


class ContactFilterTests(unittest.TestCase):
    def test_blocks_telegram_usernames_and_phone_formats(self):
        for text in ("Напишите @walkie_user", "Номер +7 (999) 123-45-67", "Телефон 8 999 123 45 67"):
            with self.subTest(text=text):
                self.assertTrue(app_v14.chat_contact_violation(text))

    def test_allows_normal_messages_and_non_phone_numbers(self):
        for text in ("Буду в 18:30, заказ 12345", "Ричи сегодня прошёл 2 км", "Позвоните после прогулки"):
            with self.subTest(text=text):
                self.assertEqual(app_v14.chat_contact_violation(text), "")


if __name__ == "__main__":
    unittest.main()
