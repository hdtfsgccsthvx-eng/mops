import json
import hashlib
import hmac
import tempfile
import threading
import unittest
from datetime import date, timedelta
from http.server import ThreadingHTTPServer
from urllib.error import HTTPError
from urllib.request import Request, urlopen
from unittest.mock import patch

import app_v15


class FamilyBoardingApiTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='walkie-family-api-')
        self.old_db = app_v15.base.DB
        app_v15.base.DB = self.temp.name + '/test.sqlite3'
        app_v15.init_v15()
        self.server = ThreadingHTTPServer(('127.0.0.1', 0), app_v15.Handler)
        self.server.daemon_threads = True
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.base_url = f'http://127.0.0.1:{self.server.server_port}'

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)
        app_v15.base.DB = self.old_db
        self.temp.cleanup()

    def request_json(self, path, method='GET', payload=None):
        body = None if payload is None else json.dumps(payload).encode()
        request = Request(self.base_url + path, data=body, method=method,
                          headers={'Content-Type':'application/json'})
        with urlopen(request, timeout=4) as response:
            return response.status, json.loads(response.read().decode())

    def demo_pets(self):
        _, pets = self.request_json('/api/pets')
        if not pets:
            c = app_v15.base.conn()
            c.executemany('INSERT INTO pets(user_id,name,breed) VALUES(?,?,?)',
                          [(777000,'Бублик','Корги'),(777000,'Мурка','Британская'),(777000,'Чарли','Лабрадор')])
            c.commit();c.close()
            _, pets = self.request_json('/api/pets')
        return pets

    def test_create_family_order_persists_pets_categories_and_price(self):
        pets = self.demo_pets()[:2]
        tomorrow = (date.today() + timedelta(days=2)).isoformat()
        _, created = self.request_json('/api/orders', 'POST', {
            'item_id':2,'scheduled_date':tomorrow,'scheduled_time':'12:00',
            'duration_min':1440,'address':'Тестовая улица, 1',
            'pet_id':pets[0]['id'],'pet_ids':[p['id'] for p in pets],
            'boarding_pet_categories':{str(pets[0]['id']):'small',str(pets[1]['id']):'medium'},
            'notes':'Позвонить у подъезда'
        })
        self.assertEqual(created['price'],4675)
        _, order = self.request_json(f"/api/orders/{created['id']}")
        self.assertEqual(json.loads(order['pet_ids_json']),[p['id'] for p in pets])
        self.assertEqual(json.loads(order['pet_categories_json']),{str(pets[0]['id']):'small',str(pets[1]['id']):'medium'})
        self.assertEqual(order['customer_notes'],'Позвонить у подъезда')
        self.assertIn('Семейная скидка 15%',order['notes'])

    def test_create_family_order_rejects_pet_owned_by_someone_else(self):
        pets = self.demo_pets()
        c = app_v15.base.conn()
        c.execute('INSERT INTO pets(user_id,name,breed) VALUES(?,?,?)',(123,'Не мой питомец','Тест'))
        outsider = c.execute('SELECT last_insert_rowid()').fetchone()[0]
        c.commit();c.close()
        tomorrow = (date.today() + timedelta(days=2)).isoformat()
        with self.assertRaises(HTTPError) as error:
            self.request_json('/api/orders','POST',{
                'item_id':2,'scheduled_date':tomorrow,'scheduled_time':'12:00',
                'duration_min':1440,'address':'Тестовая улица, 1',
                'pet_id':pets[0]['id'],'pet_ids':[pets[0]['id'],outsider],
                'boarding_pet_categories':{str(pets[0]['id']):'small',str(outsider):'medium'}
            })
        self.assertEqual(error.exception.code,400)
        self.assertIn('не найден',error.exception.read().decode().lower())
        error.exception.close()

    def test_website_interest_is_saved_retried_and_reflected_in_feed(self):
        c = app_v15.base.conn()
        c.execute("INSERT OR IGNORE INTO users(id,first_name,city,executor_enabled) VALUES(777000,'Алина','Санкт-Петербург',1)")
        c.execute("UPDATE users SET executor_enabled=1,city='Санкт-Петербург' WHERE id=777000")
        c.execute("INSERT OR REPLACE INTO executor_profiles(user_id,display_name,city,area,services_json,active) VALUES(777000,'Алина','Санкт-Петербург','Центральный','[1]',1)")
        c.execute("INSERT OR REPLACE INTO site_requests(site_request_id,service,city,district,scheduled_date,scheduled_time,status,created_at,updated_at) VALUES(991,'walk','spb','Центральный','2026-10-20','12:00','matching','2026-10-17','2026-10-17')")
        c.commit(); c.close()
        headers = {'X-Telegram-Init-Data':'test-user', 'Content-Type':'application/json'}
        with patch.object(app_v15.base, 'validate_init_data', return_value={'id':777000,'first_name':'Алина'}), \
             patch.object(app_v15, 'push_site_interest', side_effect=[False, True]) as deliver, \
             patch.object(app_v15.Handler, 'notify_site_managers') as notify:
            request = Request(self.base_url+'/api/site-requests', headers=headers)
            with urlopen(request, timeout=4) as response:
                initial = json.loads(response.read().decode())['requests'][0]
            self.assertFalse(initial['already_interested'])
            _, first = self._request_with_auth('/api/site-requests/991/interest', headers)
            self.assertFalse(first['site_synced'])
            self.assertEqual(first['sync_status'], 'failed')
            request = Request(self.base_url+'/api/site-requests', headers=headers)
            with urlopen(request, timeout=4) as response:
                pending = json.loads(response.read().decode())['requests'][0]
            self.assertTrue(pending['already_interested'])
            self.assertFalse(pending['interest_synced'])
            _, second = self._request_with_auth('/api/site-requests/991/interest', headers)
            self.assertTrue(second['already'])
            self.assertTrue(second['site_synced'])
            self.assertEqual(second['sync_attempts'], 2)
            request = Request(self.base_url+'/api/site-requests', headers=headers)
            with urlopen(request, timeout=4) as response:
                delivered = json.loads(response.read().decode())['requests'][0]
            self.assertTrue(delivered['interest_synced'])
            self.assertEqual(deliver.call_count, 2)
            notify.assert_called_once()

    def test_site_integration_ping_http_endpoint(self):
        old_secret = app_v15.WALKIE_SITE_WEBHOOK_SECRET
        app_v15.WALKIE_SITE_WEBHOOK_SECRET = 'shared-test-secret'
        try:
            payload = {'event':'walkie.integration.ping','nonce':'wp-diag-9f3a','occurred_at':app_v15.v14.now_iso()}
            body = json.dumps(payload, separators=(',',':')).encode()
            signature = 'sha256='+hmac.new(b'shared-test-secret',body,hashlib.sha256).hexdigest()
            request = Request(self.base_url+'/integrations/walkie/site-ping',data=body,method='POST',
                              headers={'Content-Type':'application/json','X-Walkie-Signature':signature})
            with urlopen(request,timeout=4) as response:
                result = json.loads(response.read().decode())
            self.assertEqual(result,{'ok':True,'event':'walkie.integration.ping','nonce':'wp-diag-9f3a'})
        finally:
            app_v15.WALKIE_SITE_WEBHOOK_SECRET = old_secret

    def _request_with_auth(self, path, headers):
        request = Request(self.base_url+path, data=b'{}', method='POST', headers=headers)
        with urlopen(request, timeout=4) as response:
            return response.status, json.loads(response.read().decode())


if __name__ == '__main__':
    unittest.main()
