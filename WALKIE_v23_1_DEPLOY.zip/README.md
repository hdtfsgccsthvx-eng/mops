# WALKIE v23.1 — Railway deploy

Built from the user-supplied `WALKIE_TELEGRAM_MINIAPP_v23.1_INSTALL.zip`.

Run one service with Dockerfile, production env `TEST_MODE=false`, `BOT_TOKEN` and `MINI_APP_URL`.
Mount a Railway persistent volume at `/data`. SQLite and uploaded images live there.
Telegram webhook is configured automatically on startup at `<MINI_APP_URL>/telegram/webhook`.
Set `TELEGRAM_WEBHOOK_SECRET` (optional but recommended), which verifies all inbound Telegram updates.
The old root `bot.py` (join request approval prototype) is deliberately excluded.

Site CRM integration is optional. Set `WALKIE_SITE_WEBHOOK_SECRET` and
`WALKIE_SITE_CALLBACK_URL` only when corresponding WordPress integration is ready.
Do not put credentials into git: use Railway service variables.

Local tests: `python -m unittest discover -s tests -v`.
Healthcheck: `GET /health`.
